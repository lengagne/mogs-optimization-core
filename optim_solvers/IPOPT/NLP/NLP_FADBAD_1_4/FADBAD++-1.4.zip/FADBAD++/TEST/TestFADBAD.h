#ifndef TEST_FADBAD_H
#define TEST_FADBAD_H

#include "IReportLogger.h"

class TestFADBAD : public IReportLogger
{
	public:
	void run(IReportLog& rlog);
};

#endif





